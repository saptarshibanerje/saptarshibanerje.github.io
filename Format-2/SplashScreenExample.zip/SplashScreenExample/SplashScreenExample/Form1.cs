﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace SplashScreenExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblVersion.Text = "Version: " + Assembly.GetExecutingAssembly().GetName().Version.ToString();
            bgwChecks.WorkerReportsProgress = true;
            bgwChecks.RunWorkerAsync();

        }

        private void bgwChecks_DoWork(object sender, DoWorkEventArgs e)
        {
            if (!VersionChecking())
            {
                new frmDownload().ShowDialog();
            }
            //bgwChecks.ReportProgress();
            //for (int i = 1; i <= 100; i++)
            //{
            //    // Wait 50 milliseconds.  
            //    Thread.Sleep(50);
            //    // Report progress.  
            //    bgwChecks.ReportProgress(i);
            //}
        }

        private void bgwChecks_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            // Change the value of the ProgressBar   
            progressBar1.Value = e.ProgressPercentage;
            // Set the text.  
            progressBar1.Text = e.ProgressPercentage.ToString();
        }

        private bool VersionChecking()
        {
            bool result = true;
            List<VersionModel> versionModels = new List<VersionModel>();
            int curentVersion = 0;
            int runningVersion = -1;
            using (var w = new WebClient())
            {
                var json_data = string.Empty;
                try
                {
                    json_data = w.DownloadString("https://sbdr.github.io/version.json");
                    versionModels = JsonConvert.DeserializeObject<List<VersionModel>>(json_data);
                }
                catch (Exception ex) { }
                // if string with JSON data is not empty, deserialize it to class and return its instance 
                //return !string.IsNullOrEmpty(json_data) ? JsonConvert.DeserializeObject<T>(json_data) : new T();

            }
            if (versionModels.Count > 0)
            {
                if (versionModels.Any(x => x.StoreName.ToLower() == "gourangostores1"))
                {
                    curentVersion = Convert.ToInt32(versionModels.Where(x => x.StoreName.ToLower() == "gourangostores1").FirstOrDefault().Version);
                    runningVersion = Convert.ToInt32(Assembly.GetExecutingAssembly().GetName().Version.ToString().Replace(".", ""));
                }


            }
            if (curentVersion != runningVersion)
            {
                result = false;
            }

            return result;
        }
    }
}
